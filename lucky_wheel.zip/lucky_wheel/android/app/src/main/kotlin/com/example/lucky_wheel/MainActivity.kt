package com.example.lucky_wheel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
